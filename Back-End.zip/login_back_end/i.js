import express from "express";
import cors from "cors";
import mongoose from "mongoose";
const app = express();
app.use(express.json());
app.use(cors());
const router = express.Router();

mongoose.connect(
  "mongodb://localhost:27017/MyLogin1",
  {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  },
  () => {
    console.log("DB Connected");
  }
);

const useSchema = new mongoose.Schema({
  project_name: String,
  reason: String,
  type: String,
  password: String,
  division: String,
  category: String,
  priority: String,
  department: String,
  location: String,
  s_date: Date,
  e_date: Date,
  status1: String,
});

const User = new mongoose.model("User", useSchema);

app.post("/project", (req, res) => {
  const {
    project_name,
    reason,
    type,
    division,
    category,
    priority,
    department,
    location,
    s_date,
    e_date,
    status1,
  } = req.body;
  User.findOne({ project_name: project_name }, (err, user) => {
    if (user) {
      res.send({ message: "Error405" });
    } else {
      const user = new User({
        project_name,
        reason,
        type,
        division,
        category,
        priority,
        department,
        location,
        s_date,
        e_date,
        status1,
      });
      user.save((err) => {
        if (err) {
          res.send(err);
        } else {
          res.send({ message: "Succesgully Saved" });
        }
      });
    }
  });
});

app.get("/project/getProjectData", (req, res) => {
  User.find().exec((err, user) => {
    if (err) {
      return res.status(400).json({ Error: "No Orders found in DB" });
    }
    res.json(user);
    console.log(user);
  });
});

app.listen(5000, () => {
  console.log("Connected on port 5000");
});
