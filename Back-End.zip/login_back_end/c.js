import express from "express";
import cors from "cors";
import mongoose from "mongoose";
const app = express();
app.use(express.json());
app.use(cors());
const router = express.Router();

mongoose.connect(
  "mongodb://localhost:27017/CategoryMaster",
  {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  },
  () => {
    console.log("DB Connected");
  }
);

const useSchema = new mongoose.Schema({
  category_name: String,
  status: String,
  createdAt: Date,
  updatedAt: Date,
});

const User = new mongoose.model("User", useSchema);

app.post("/project1", (req, res) => {
  const { category_name, status, createdAt, updatedAt } = req.body;
  User.findOne({ category_name: category_name }, (err, user) => {
    if (user) {
      res.send({ message: "Error405" });
    } else {
      const user = new User({
        category_name,
        status,
        createdAt,
        updatedAt,
      });
      user.save((err) => {
        if (err) {
          res.send(err);
        } else {
          res.send({ message: "Succesgully Saved" });
        }
      });
    }
  });
});

app.get("/project1/getProjectData", (req, res) => {
  User.find().exec((err, user) => {
    if (err) {
      return res.status(400).json({ Error: "No Orders found in DB" });
    }
    res.json(user);
    console.log(user);
  });
});

app.listen(5001, () => {
  console.log("Connected on port 5001");
});
