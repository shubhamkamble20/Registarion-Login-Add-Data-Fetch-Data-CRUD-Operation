import express from "express"
import cors from "cors"
import mongoose from "mongoose"

const app = express()
app.use(express.json())
{/* app.use(express.urlencoded()) */}
app.use(cors())



mongoose.connect("mongodb://localhost:27017/MyLogin", {
 useNewUrlParser: true,
 useUnifiedTopology: true
}, () => {
 
console.log("DB Connected")
})

 {/* const ProjectRouter = require('./route/project.js').default; */}


const useSchema = new mongoose.Schema({
    n1: String,
    name: String,
    email: String,
    password: String
})

const User = new mongoose.model("User", useSchema)

{/* const useSchema2 = new mongoose.Schema({
    name: String,
    email: String,
    password: String
}) */}




//  const user1Schema = new mongoose.Schema({
//      n2: String,
//      reason: String,
//      type: String,
//      password: String,
//      division: String,
//      category: String,
//      priority: String,
//      department: String,
//      location: String,
    
//  })
//  const User = new mongoose.model("user", user1Schema)

//const projectlist1 = new mongoose.model("projectlist1", useSchema)
//Routes
app.post("/login", (req, res) => {
 const { email, password} = req.body
 User.findOne({ email: email}, (err, user) => {
     if(user){
            if(password === user.password ){
            res.send({message: "Login Succesfully", user: user})
              }  else{
                res.send({message: "User Not Registered"})
            }
            
     }
     else{
         res.send({message:"User not registered"})
     }
 })
})



 
  

app.post("/register", (req, res) => {
    const { n1, name, email, password} = req.body
    User.findOne({email: email}, (err, user) => {
        if(user){
            res.send({message: "User allready Register"})
        }

        else{
            const user = new User({
                n1,
                name,
                email,
                password
            })
    user.save(err => {
        if(err) {
            res.send(err)
        }
        else {
            res.send( { message: "Succesgully register"})
        }
    })
}
})
})


// app.post("/project", (req, res) => {
//     const { n2, reason, type, division, category, priority, department, location} = req.body
//     User.findOne({n2: n2}, (err, user) => {
//         if(user1){
//             res.send({message: "Project Saved Succesfully"})
//      }

//         else{
//             const user = new User({
//                 n2,
//                 reason, 
//                 type, 
//                 division, 
//                 category, 
//                 priority, 
//                 department, 
//                 location
//             })
//     user.save(err => {
//         if(err) {
//             res.send(err)
//         }
//         else {
//             res.send( { message: "Succesgully register"})
//         }
//     })
// }
// })
// })


 {/* app.use("/project",ProjectRouter); */}

app.listen(9002,() => {
    console.log("Connected on port 9002")
})