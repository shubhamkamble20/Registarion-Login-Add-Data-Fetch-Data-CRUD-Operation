//const express = require('express');
import cors from "cors"
import express from "express"
import mongoose from "mongoose"
import MongoClient  from "mongoose"
const app = express()
app.use(express.json())

{/* app.use(express.urlencoded()) */}
app.use(cors())
var database

// mongoose.connect("mongodb://localhost:27017/MyLogin1", {
//  useNewUrlParser: true,
//  useUnifiedTopology: true
// }, () => {
 
// console.log("DB Connected")
// })

app.get('http://localhost:5000/project', (req, resp) => {
    database.collection('user').find({}).toArray((err, result) => {
        resp.send(result)
    })
})
app.listen(3004,() => {
    MongoClient.connect('mongodb://localhost:27017', { useNewUrlParser: true}, (error, result) =>{
        if(error) throw error
       // database = result.db('MyLogin1')
    })
    console.log("Connected on port 9002")
})