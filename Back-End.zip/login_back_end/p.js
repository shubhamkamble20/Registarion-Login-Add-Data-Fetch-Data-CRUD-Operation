import express from "express";
import cors from "cors";
import mongoose from "mongoose";
const app = express();
app.use(express.json());
app.use(cors());
const router = express.Router();

mongoose.connect(
  "mongodb://localhost:27017/ProductMaster",
  {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  },
  () => {
    console.log("DB Connected");
  }
);

const useSchema = new mongoose.Schema({
  product_name: String,
  price: String,
  quantity: String,
  category_id: String,
  createdAt: Date,
  updatedAt: Date,
});

const User = new mongoose.model("User", useSchema);

app.post("/project2", (req, res) => {
  const { product_name, price, quentity, category_id, createdAt, updatedAt } =
    req.body;
  User.findOne({ product_name: product_name }, (err, user) => {
    if (user) {
      res.send({ message: "Error405" });
    } else {
      const user = new User({
        product_name,
        price,
        quentity,
        category_id,
        createdAt,
        updatedAt,
      });
      user.save((err) => {
        if (err) {
          res.send(err);
        } else {
          res.send({ message: "Succesgully Saved" });
        }
      });
    }
  });
});

app.get("/project2/getProjectData", (req, res) => {
  User.find().exec((err, user) => {
    if (err) {
      return res.status(400).json({ Error: "No Orders found in DB" });
    }
    res.json(user);
    console.log(user);
  });
});

app.listen(5003, () => {
  console.log("Connected on port 5003");
});
